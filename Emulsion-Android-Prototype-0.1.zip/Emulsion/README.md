# Emulsion — Android grain editor (prototype 0.1)

An offline Android photo editor prototype focused on a physically-inspired stochastic film-grain model.

## Current scope
- Import a photo from the Android photo picker.
- Preview grain at up to 1400 px on the long edge.
- Adjust grain amount, estimated particle diameter (µm), size spread, clumping, tone dependence, chroma and assumed negative format.
- Export a full-resolution JPEG to `Pictures/Emulsion`.
- Deterministic grain seed so the pattern remains stable while settings change.

## Scientific status — important
This first renderer is a **physically-inspired prototype**, not a validated reproduction of Kodak, Fujifilm or any other commercial emulsion. It uses correlated Gaussian random fields at multiple spatial scales, a signal-dependent variance curve, partially correlated RGB fields and a negative-format-to-pixel scale estimate. The input is treated as a positive scan and luminance is only a proxy for negative exposure.

For a scientifically defensible next version, the model needs calibration data: high-resolution, minimally processed scans of uniformly exposed patches from known film stocks, scanned at known optical resolution, plus measured characteristic curves and preferably noise-power spectra. The renderer should then fit its scale, variance and cross-channel covariance to those measurements.

## Build
1. Open this folder in Android Studio (Hedgehog or newer; a current stable version is recommended).
2. Install Android SDK Platform 35 and JDK 17 if Android Studio asks.
3. Allow Gradle sync.
4. Run the `app` configuration on an Android 10+ device or emulator.

The project intentionally does not include a Gradle wrapper JAR. Android Studio can import and sync the project; a wrapper can be generated from the IDE/Gradle installation.

## Known prototype limitations
- CPU renderer; large full-resolution exports may take time and memory.
- The grain model is not yet calibrated against physical film measurements.
- Current preview refresh is immediate and can be computationally expensive while dragging sliders; the next iteration should debounce updates and move rendering to a managed coroutine scope.
- No RAW decoding, TIFF export, 16-bit pipeline, ICC profile management or metadata preservation yet.
